// Problem without array
const animal1 = "Cat";
const animal2 = "Dog";
const animal3 = "Fish";
// .....
const animal100 = "Bird";

// Membuat variable array menggunakan const
const animals = ["Cat", "Dog", "Fish", "Bird"];

/**
 * Mengakses element atau nilai array.
 * Mengakses element berdasarkan index atau posisi.
 * Posisi (index) dimulai dari 0.
 */
console.log(animals[0], animals[1]);
