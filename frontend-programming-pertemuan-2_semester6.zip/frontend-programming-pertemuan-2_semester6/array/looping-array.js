// Membuat variable array menggunakan const
const animals = ["Cat", "Dog", "Fish", "Bird"];

// Looping array menggunakan for
for (let i = 0; i < animals.length; i++) {
  console.log(`Hewan: ${animals[i]}`);
}
