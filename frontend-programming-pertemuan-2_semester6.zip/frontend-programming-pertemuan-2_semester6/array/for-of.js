// Membuat variable array menggunakan const
const animals = ["Cat", "Dog", "Fish", "Bird"];

// Looping array menggunakan for-of
for (const animal of animals) {
  console.log(`Hewan: ${animal}`);
}
