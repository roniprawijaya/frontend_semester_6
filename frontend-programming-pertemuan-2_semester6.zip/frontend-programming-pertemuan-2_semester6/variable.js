/**
 * Membuat variable dengan keyword const.
 * Variable const tidak dapat diubah nilainya.
 */
const name = "Aufa Billah";
const major = "Informatics";

console.log(name, major);
