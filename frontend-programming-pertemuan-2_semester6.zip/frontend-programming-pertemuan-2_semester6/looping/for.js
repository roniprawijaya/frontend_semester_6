/**
 * Looping menggunakan for.
 * Menampilkan angka 1 - 10.
 */
for (let i = 1; 1 < 11; i++) {
  console.log(`Perulangan ke: ${i}`);
}
