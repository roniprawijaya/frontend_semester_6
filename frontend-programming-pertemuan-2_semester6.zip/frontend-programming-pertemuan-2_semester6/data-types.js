const name = "Aufa Billah"; // string
const age = 23; // number
const isMarried = false; // boolean
let dateAt; // undefined

/**
 * operator typeof untuk mengecek tipe data.
 */
console.log(typeof name, typeof age);
